# kanbansys

EE333 Fall 2021 P1 (through P3)

This supports the UAB Course EE333 being offered Fall 2021 as an online course.  P1, P2, P3 are individual projects but the code here represents a common starting point for all to save some typing.
