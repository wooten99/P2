/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uab.wooten99.kanbansys;

/**
 *
 * @author Cole
 *
/**/

public abstract class Field implements Comparable < Field > {
    

	protected String name;              // Name of field
	protected String type;              // Type of field
	protected String value;             // Value of field
	protected String valueString;       // Field as string
	protected String valueDate;         // Field date
	protected String initialState;      // Field first state
	protected String list;              // Field name list
	protected String date;              // Field date list
	protected Field Field;              // Field list
	protected Field newField;           // New field introduced

/**
   * Create fields with name, type, and other fields
   *
   * @param name the name of the field and @param type the type of field
   * @param type
   */
	public Field (String name, String type) {
            
                this.name = name;
		this.type = type;
		this.value = "fieldName1";
		this.valueDate = "DateField";
		this.valueString = "StringField";
		this.initialState = "";
		this.list = initialState;
		this.date = "20210806";
                
  }

/**
   * get the name of the field
   *
   * @return string representation of the field name
   */
        
public String getName() {
            
    return name;
    
	}


	
/**
   * Makes a new field with same type and parameters but new value
   *
   * @return the object of the new field
   */
public Field newField() {
            
			Field f = new f(name,type);
			f.value = "";
			return f;
                        
	}


/**
   * Whether or not the name is a field name
   *
   * @return true or false for a specific name
   */
	public boolean isName() {
            
		return name.equals ( name );
                
	}

        
        
/**
   * get value of the field
   *
   * @return string representation of the value for a field
   */
        
@Override

  public String toString() {
      
    return value;
    
  }

  
/**
   * get Tagged String of the field
   *
   * @return string representation of the tagged string for a field
   */
public String getTaggedString() {
    
		return name + ": " + value;
                
	}

/**
   * get what kind of field it is
   *
   * @return string representation for field type
   */

	public String getType() {
            
		return type;
                
	}

/**
   * Compare two fields
   *
   * @param object
   * @return the two compared fields
   */
        
@Override
        
public int compareTo(Field object) {
    
		return Field.compareTo(Field);
                
	}

/**
   * outputs the value, whether 1, 0, or -1
   *
   * @param field
   * @param value
   * @return the integer value of the compared fields
   */

	public int valueCompareTo(Field field, Field value) {
            
			return Field.compareTo(value);
                        
		}
        
	}
