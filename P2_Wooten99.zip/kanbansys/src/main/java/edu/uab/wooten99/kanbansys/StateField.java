/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uab.wooten99.kanbansys;

/**
 *
 * @author Cole
 */
    /**A subclass for the superclass, field, to get the name, and initial states for each field along
 * with the list array*/
public class StateField extends Field {

	/**
   * able to use StateField within the superclass and KanbanCard
   *
	 * @param name
	 * @param list
	 * @param initialState
   */
  public StateField(String name, String[] list, String initialState) {
    super(name, "state");
	}

	/**
   * get string array of the field
   *
   * @return string array, within initialState, for fields in StateField
   */
  public String[] get() {
    return new String[] {initialState};
	}

	/**
   * Makes a new field with same type and parameters but new value
   *
   * @return the object of the new field
   */
  @Override
  public Field newField() {
		Field f = new f(name,type);
		f.value = "";
		return f;
	}
}