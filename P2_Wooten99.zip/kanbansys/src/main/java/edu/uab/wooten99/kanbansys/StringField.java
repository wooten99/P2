/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uab.wooten99.kanbansys;

/**
 *
 * @author Cole
 */
    /**A subclass for the superclass, field, to get the name and valueStrings as a string */
public class StringField extends Field {

	/**
   * able to use StringField within the superclass and KanbanCard
   *
	 * @param name
	 * @param valueString
   */
	public StringField(String name, String valueString) {
		super( name, "String");
	}

	/**
   * get name and valueString of the field
   *
   * @return string representation for name and valueString
   */
	public String get() {
		return "";
	}
}