/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uab.wooten99.kanbansys;

/**
 *
 * @author Cole
 */
  
public class KanbanDate {                   // Provides KanbanDate

	protected String date;              // Represent the date as a string, protected

	/**
   * Create the date of the field by initializing it
   *
   * @param date the date of the field
   */
	public KanbanDate( String date) {   // sets the date as today's date
		this.date = date;
	}

	/**
   * get date of the field
   *
   * @return string representation of the date for a field
   */
	@Override                           // Overrides method from java.lang.Object
	public String toString() {          // returns the date
		return date;
	}
}  