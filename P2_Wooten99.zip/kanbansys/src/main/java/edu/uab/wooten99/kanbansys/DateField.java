/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uab.wooten99.kanbansys;

/**
 *
 * @author Cole
 */
    /**A subclass for the superclass, field, to get the KanbanDate, date, as a string */
    
public class DateField extends Field {
		
    protected KanbanDate date;

	/**
   * able to use DateField within the superclass and KanbanCard
   *
	 * @param name
	 * @param date
   */
	public DateField(String name, KanbanDate date) {
            
		super ( name, "date" );
	}

/**
   * get date of the field
   *
   * @return string representation for date of the field
   */

	public KanbanDate get() {
			return date;
		}
	}