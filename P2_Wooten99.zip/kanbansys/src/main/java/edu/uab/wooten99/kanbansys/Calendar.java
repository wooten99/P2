/*
 * Author: David Green <wooten99@uab.edu>
 * Assignment:  ee333fallp1 - EE333 Fall 2021
 *
 * Credits:  (if any for sections of code)
 */
package edu.uab.wooten99.kanbansys;

/** Fake calendar (Static data, static methods only */
public class Calendar {

  private static String theDate = "TBD";


  Calendar() {}

  /**
   * Sets the calendar to specified date
   *
   * @param date representation of data as String
   */
  public static void setDate(String date) {
    if (date != null) {
      theDate = date;
    }
  }

  /**
   * Provides the fake calendar date
   *
   * @return String representation of date from calendar
   */
  public static String getDate() {
    return theDate;
  }
}
