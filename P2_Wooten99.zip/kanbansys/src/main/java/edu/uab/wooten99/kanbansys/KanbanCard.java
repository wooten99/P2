/*
 * Author: Cole Wooten <wooten99@uab.edu>
 * Assignment:  ee333fallp1 - EE333 Fall 2021
 *
 * Credits:  (if any for sections of code)
 */
package edu.uab.wooten99.kanbansys;

/** Model a Kanban Card */
public class KanbanCard {
    
    private String name;
    private String uid;
    private String createdate;
    private String beginDate;
    private String endDate;
    private String state;
    private static long count = 10000000;
    private String StateLog;
    private String notes;
    
 
  /**
   * Create a Kanban card with a unique uid, and Initialize other fields appropriately
   *
   * @param name the name of the card
   */
 
  public KanbanCard(String name) {
  
    this.name = name;
    this.createdate = Calendar.getDate();
    this.beginDate = "TBD";
    this.endDate = "TBD";
    this.uid = "" + count;
    this.state = "BACKLOG";
    this.notes = "";
    
  }

  /**
   * get the UID of the card
   *
   * @return long number corresponding to uid of card
   */
  public String getUid() {
    return uid; 
  }

  /**
   * get the name of the task
   *
   * @return String representing name of task
   */
  public String getName() {
    return name;
  }

  /**
   * Is this task done?
   *
   * @return true if task has been completed
   */
  public boolean isDone() {
      
     if (state.equals("done")){
         return true;
     }
     return false;
  }

  /**
   * Is this task active?
   *
   * @return true if not in backlog, not done or not abandoned
   */
  public boolean isActive() {
      if (state.equals("Active")){
          return true;
      }
    return false;
  }

  /**
   * Is this task abandoned?
   *
   * @return true if task has been abandoned
   */
  public boolean isAbandoned() {
      if (state.equals("Abandoned")){
          return true;
      }
    return false;
  }

  /**
   * Create a string representation of the Kanban card
   *
   * <p>Format:
   *
   * <p><code>
   * uid: Name of task Task State
   * state - Create: date (or tbd) Begin: date (or tbd) Completed: date (or TBD)
   * (notes would go here if any)
   * </code>
   *
   * <p>Example:
   *
   * <p><code>
   * 100000000: Demo task Backlog
   * BACKLOG - Create: 20210815 Begin: TBD Completed: TBD
   * </code>
   *
   * @return formatted string
   */
  @Override
  public String toString() {
      return uid
        + ":"
        + " "
        + name
        + "\n"
        + state
        + " "
        + "-"
        + " "
        + "Create:"
        + " "
        + createdate
        + " "
        + "Begin:"
        + " "
        + beginDate
        + " "
        + "Completed:"
        + " "
        + endDate
        + "\n"
        + notes;
      
  }
            

  /** @param newName the new task name */
  public void updateName(String newName) {
   name = newName;
}

  /**
   * Mark the task as in design if it is in the backlog (no action otherwise) and capture note if
   * non-null
   *
   * @param note a String note or null, if non-null, a newline will be prepended to the added note
   */
  public void start(String note) {
  if ("BACKLOG".equals(state)){
      state = "DESIGN";
      notes += note + "\n";
      beginDate = Calendar.getDate();
  }
  }

  /**
   * Mark and timestamp (if beginDate null) the task as in build if it was in design (no action
   * otherwise) and capture note if non-null
   *
   * @param note a String note or null, if non-null, a newline will be prepended to the added note
   */
  public void build(String note) {
  if ("DESIGN".equals(state)){
      state = "BUILD";
      notes += note + "\n";
  }
  }

  /**
   * Mark the task as in test if it was in build (no action otherwise) and capture note
   *
   * @param note a String note or null, if non-null, a newline will be prepended to the added note
   */
  public void test(String note) {
      if ("BUILD".equals(state)){
      state = "TEST";
      notes += note + "\n";
      }
      }

  /**
   * Mark the task as ready to release if it was in test (no action otherwise) and capture note
   *
   * @param note a String note or null, if non-null, a newline will be prepended to the added note
   */
  public void release(String note) {
  if ("TEST".equals(state)){
      state = "RELEASE";
      notes += note + "\n";
      }
  }

  /**
   * Mark and timestamp the task as complete if it was in release (no action otherwise) and capture
   * note
   *
   * @param note a String note or null, if non-null, a newline will be prepended to the added note
   */
  public void complete(String note) {
  if ("RELEASE".equals(state)){
      state = "COMPLETE";
      notes += note + "\n";
      }
  }

  /**
   * Mark the task as abandoned unless it was completed (no action otherwise) and capture note
   *
   * @param note a String note or null, if non-null, a newline will be prepended to the added note
   */
  public void abandon(String note) {
  if ("done".equals(state)) {
      state = "ABANDON";
  }
  }

  /**
   * Modify the state of the task and capture the note, update the date fields based on present new
   * state
   *
   * @param state the new KCardState for the task
   * @param note a String note or null, if non-null, a newline will be prepended to the added note
   */
  public void move(String state, String note) {
  this.state = state;
  if (note != null){
      notes += note + "\n";
  }
  }
}
